﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


public partial class Form : System.Web.UI.Page
{
    public static int i, count = 0;
    string varea, vgender, vage, valchoholic, vtime, vtov, vspeedl, vacci;
    // SqlDataReader rdr = null;
    SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\divya\\Documents\\Project.mdf;Integrated Security=True;Connect Timeout=30");
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {

        con.Open();
        SqlCommand cmd = new SqlCommand("select * from [Table]", con);
        SqlDataReader rd = null;
        varea = DropDownList1.SelectedItem.Text;
        vgender = RadioButtonList1.SelectedValue;
        vage = RadioButtonList2.SelectedValue;
        valchoholic = RadioButtonList3.SelectedValue;
        vtime = DropDownList2.SelectedItem.Text;
        vtov = DropDownList3.SelectedItem.Text;
        vspeedl = DropDownList4.SelectedItem.Text;
        Response.Write(varea + "" + vgender + "" + vage + "" + valchoholic + "" + vtime + "" + vtov + "" + vspeedl);
        Label1.Text = Convert.ToString(varea);
    }
}